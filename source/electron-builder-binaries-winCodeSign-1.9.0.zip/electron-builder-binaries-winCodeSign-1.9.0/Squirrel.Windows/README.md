The files in this folder are from Squirrel for Windows 1.2.3
